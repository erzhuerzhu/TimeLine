package com.yuqipu.TimeLife;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TimeLifeApplication {

	public static void main(String[] args) {
		SpringApplication.run(TimeLifeApplication.class, args);
	}

}
