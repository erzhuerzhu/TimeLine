package com.yuqipu.TimeLine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TimeLineApplication {

	public static void main(String[] args) {
		SpringApplication.run(TimeLineApplication.class, args);
	}

}
