package com.yuqipu.TimeLine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TimeLineApplicationTests {

	@Test
	void contextLoads() {
	}

}
